﻿using Microsoft.AspNetCore.Mvc;
using Hackathon;
using Hackathon.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hackathon.Controllers
{
    [Route("/")]
    public class HomeController : Controller
{

    CsdrPenaltyContext db = new CsdrPenaltyContext();
    Country c1 = new Country();
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        
        _logger = logger;
    }
     [HttpGet]
    public IActionResult Index()
        {
            /*var tables = new  
                {  
                    Employees=db.Employees.ToList(),  
                    Departments=db.Departments.ToList(),  
                    Incentives=db.Incentives.ToList()  
                }; */

            List<Country> countries = db.Countries.ToList();
            ViewBag.CountryTbl = new SelectList(countries, "Countryid", "Name");
            HolidayCalendar rv = c1.GetcountriesDetails();
            int? ci;
            ci = rv.Cid;
            ViewBag.HolidayTbl = db.Countries.FirstOrDefault(d => d.Countryid.Equals(ci));
            //ViewBag.HolidayCalendars = db.HolidayCalendars;
            //  List<HolidayCalendar> Holidaycalendars = GetHolidayData(); 



            return View();
                }
           }
    }
using Microsoft.AspNetCore.Mvc;
using Hackathon;
using Hackathon.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hackathon.Controllers
{
  [Route("/holiday")]
    public class HolidayController : Controller
{
      CsdrPenaltyContext db = new CsdrPenaltyContext();
      Country c1 = new Country();
        
       private readonly ILogger<HomeController> _logger;

    public HolidayController(ILogger<HomeController> logger)
    {
        
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Index()
    {
      
       ViewBag.countries = db.Countries;
       List<Country> countries = db.Countries.ToList();
       ViewBag.CountryTbl = new SelectList(countries,"Countryid","Name");
       HolidayCalendar  rv = c1.GetcountriesDetails();
       int ?ci;
       ci = rv.Cid;
       ViewBag.HolidayTbl = db.Countries.FirstOrDefault(d => d.Countryid.Equals(ci));

       return View();
    }

    [HttpPost]
     public IActionResult Index(HolidayCalendar calendar)
    {
           
           if (ModelState.IsValid)
            {
              db.HolidayCalendars.Add(calendar);
              db.SaveChanges();
                
           Response.Redirect("/holiday");
           
            }

            return View(calendar);
    }
  }
}
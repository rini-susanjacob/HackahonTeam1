﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class Login
{
    public string EmailId { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string RemarksComments { get; set; } = null!;

    public DateOnly DateOfJoin { get; set; }

    public long Id { get; set; }

    public bool IsActiveorNot { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class HolidayCalendar
{
    public int Id { get; set; }

    public DateOnly HolidayDate { get; set; }

    public DateOnly LastUpdatedDate { get; set; }

    public int? Cid { get; set; }

    public string? Description { get; set; }

    public virtual Country? CidNavigation { get; set; }

   

   
}

﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Hackathon.Models;

public partial class CsdrPenaltyContext : DbContext
{
    public CsdrPenaltyContext()
    {
    }

    public CsdrPenaltyContext(DbContextOptions<CsdrPenaltyContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Authorization> Authorizations { get; set; }

    public virtual DbSet<Country> Countries { get; set; }

    public virtual DbSet<HolidayCalendar> HolidayCalendars { get; set; }

    public virtual DbSet<LoggerTable> LoggerTables { get; set; }

    public virtual DbSet<Login> Logins { get; set; }

    public virtual DbSet<RegistrationTable> RegistrationTables { get; set; }

    public virtual DbSet<SecurityPenaltyRate> SecurityPenaltyRates { get; set; }

    public virtual DbSet<SecurityPrice> SecurityPrices { get; set; }

    public virtual DbSet<Transaction> Transactions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseNpgsql("Server=127.0.0.1;Port=5432;Database='CSDR penalty ';User Id=postgres;Password=Jain@7899;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Authorization>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Authorization_pkey");

            entity.ToTable("Authorization");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.AccessPage)
                .HasMaxLength(1)
                .HasColumnName("Access Page");
            entity.Property(e => e.Authorized).HasMaxLength(1);
            entity.Property(e => e.EmailId)
                .HasMaxLength(1)
                .HasColumnName("Email_Id");
            entity.Property(e => e.FirstName).HasMaxLength(1);
            entity.Property(e => e.LastName)
                .HasMaxLength(1)
                .HasColumnName("Last Name");
        });

        modelBuilder.Entity<Country>(entity =>
        {
            entity.HasKey(e => e.Countryid).HasName("country_id_pk");

            entity.ToTable("country");

            entity.Property(e => e.Countryid).HasColumnName("countryid");
            entity.Property(e => e.Createdby)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("createdby");
            entity.Property(e => e.Createdon)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("createdon");
            entity.Property(e => e.Lastupdatedby)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("lastupdatedby");
            entity.Property(e => e.Lastupdatedon)
                .HasDefaultValueSql("now()")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("lastupdatedon");
            entity.Property(e => e.Name)
                .HasMaxLength(12)
                .IsFixedLength()
                .HasColumnName("name");
        });

        modelBuilder.Entity<HolidayCalendar>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Holiday Calendar_pkey");

            entity.ToTable("Holiday Calendar");

            entity.HasIndex(e => e.Cid, "fki_CountryTable");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Description)
                .HasMaxLength(12)
                .IsFixedLength();
            entity.Property(e => e.HolidayDate).HasColumnName("Holiday Date");
            entity.Property(e => e.LastUpdatedDate).HasColumnName("Last Updated Date");

            entity.HasOne(d => d.CidNavigation).WithMany(p => p.HolidayCalendars)
                .HasForeignKey(d => d.Cid)
                .HasConstraintName("CountryTable");
        });

        modelBuilder.Entity<LoggerTable>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Logger Table_pkey");

            entity.ToTable("Logger Table");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.AccessPage)
                .HasMaxLength(20)
                .IsFixedLength();
            entity.Property(e => e.UserName)
                .HasMaxLength(12)
                .IsFixedLength()
                .HasColumnName("user_name");
        });

        modelBuilder.Entity<Login>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Login _pkey");

            entity.ToTable("Login ");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.DateOfJoin).HasColumnName("Date Of Join");
            entity.Property(e => e.EmailId).HasColumnName("Email_Id");
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("First Name");
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("Last Name");
            entity.Property(e => e.Password)
                .HasMaxLength(20)
                .IsFixedLength();
            entity.Property(e => e.RemarksComments)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("Remarks/comments");
        });

        modelBuilder.Entity<RegistrationTable>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("RegistrationTable_pkey");

            entity.ToTable("RegistrationTable");

            entity.HasIndex(e => e.EmailId, "Email_Id").IsUnique();

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.EmailId)
                .HasMaxLength(50)
                .IsFixedLength()
                .HasColumnName("Email Id");
            entity.Property(e => e.FirstName)
                .HasMaxLength(20)
                .IsFixedLength();
            entity.Property(e => e.LastName)
                .HasMaxLength(20)
                .IsFixedLength();
        });

        modelBuilder.Entity<SecurityPenaltyRate>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Security Penalty Rate_pkey");

            entity.ToTable("Security Penalty Rate");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.LastUpdatedDate).HasColumnName("Last Updated Date");
            entity.Property(e => e.PenaltyRate)
                .HasPrecision(12)
                .HasColumnName("Penalty Rate");
            entity.Property(e => e.ValidFromDate).HasColumnName("VALID FROM DATE");
        });

        modelBuilder.Entity<SecurityPrice>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("Security Price_pkey");

            entity.ToTable("Security Price");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.IsinSecId)
                .HasMaxLength(12)
                .IsFixedLength()
                .HasColumnName("ISIN SEC ID");
            entity.Property(e => e.Poh).HasColumnName("POH");
            entity.Property(e => e.SecurityPrice1)
                .HasPrecision(12)
                .HasColumnName("Security Price");
            entity.Property(e => e.ValidFromDate).HasColumnName("VALID FROM DATE");
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.PlaceOfHoldingTechNumber).HasName("Reports_pkey");

            entity.ToTable("Transaction");

            entity.Property(e => e.PlaceOfHoldingTechNumber)
                .ValueGeneratedNever()
                .HasColumnName("Place of Holding Tech Number");
            entity.Property(e => e.CalendarId)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("Calendar Id");
            entity.Property(e => e.CounterPartyId)
                .HasMaxLength(16)
                .IsFixedLength()
                .HasColumnName("Counter Party Id");
            entity.Property(e => e.CounterPartyRoleCd)
                .HasMaxLength(6)
                .IsFixedLength()
                .HasColumnName("Counter Party Role Cd");
            entity.Property(e => e.FailingPartyRoleCd)
                .HasMaxLength(6)
                .IsFixedLength()
                .HasColumnName("Failing Party Role Cd");
            entity.Property(e => e.InstructionTypeCode)
                .HasMaxLength(4)
                .IsFixedLength()
                .HasColumnName("Instruction Type code");
            entity.Property(e => e.Isin)
                .HasMaxLength(12)
                .IsFixedLength()
                .HasColumnName("ISIN");
            entity.Property(e => e.MatchingReference)
                .HasMaxLength(16)
                .IsFixedLength()
                .HasColumnName("Matching Reference");
            entity.Property(e => e.PartyId)
                .HasMaxLength(16)
                .IsFixedLength()
                .HasColumnName("Party Id");
            entity.Property(e => e.PartyRoleCd)
                .HasMaxLength(6)
                .IsFixedLength()
                .HasColumnName("Party Role Cd");
            entity.Property(e => e.PenaltyAmount)
                .HasPrecision(10)
                .HasColumnName("Penalty Amount");
            entity.Property(e => e.PlaceOfSettlement)
                .HasMaxLength(11)
                .IsFixedLength()
                .HasColumnName("Place of Settlement");
            entity.Property(e => e.SecurityQuantity).HasColumnName("Security Quantity");
            entity.Property(e => e.SettlementCashAmount)
                .HasPrecision(10)
                .HasColumnName("Settlement cash amount");
            entity.Property(e => e.SettlementDate).HasColumnName("Settlement Date");
            entity.Property(e => e.Sign).HasColumnType("char");
            entity.Property(e => e.TransactionTypeCode)
                .HasMaxLength(4)
                .IsFixedLength()
                .HasColumnName("Transaction Type Code");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class Authorization
{
    public short Id { get; set; }

    public char EmailId { get; set; }

    public char FirstName { get; set; }

    public char LastName { get; set; }

    public char Authorized { get; set; }

    public char AccessPage { get; set; }
}

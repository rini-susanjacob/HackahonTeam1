﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class SecurityPrice
{
    public long Id { get; set; }

    public short Poh { get; set; }

    public string IsinSecId { get; set; } = null!;

    public DateOnly ValidFromDate { get; set; }

    public decimal SecurityPrice1 { get; set; }
}

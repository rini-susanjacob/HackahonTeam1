﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class SecurityPenaltyRate
{
    public long Id { get; set; }

    public DateOnly? ValidFromDate { get; set; }

    public decimal? PenaltyRate { get; set; }

    public DateOnly? LastUpdatedDate { get; set; }
}

﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class RegistrationTable
{
    public short Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string EmailId { get; set; } = null!;
}

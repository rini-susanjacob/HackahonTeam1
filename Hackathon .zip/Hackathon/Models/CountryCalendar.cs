using Microsoft.AspNetCore.Mvc;
using Hackathon;
using Hackathon.Models;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace Hackathon.Models 
{  
    public class CountryCalendar  
    {  
        public IEnumerable<HolidayCalendar>? HolidayCalendars { get; set; }  
        public IEnumerable<Country>? Countries { get; set; }  

    
         
    }  
}
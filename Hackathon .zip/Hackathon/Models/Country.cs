﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class Country
{
    public int Countryid { get; set; }

    public string Name { get; set; } = null!;

    public DateTime? Createdon { get; set; }

    public string? Createdby { get; set; }

    public DateTime? Lastupdatedon { get; set; }

    public string? Lastupdatedby { get; set; }

    public virtual ICollection<HolidayCalendar> HolidayCalendars { get; set; } = new List<HolidayCalendar>();

     static HolidayCalendar holiday = new HolidayCalendar();

     public HolidayCalendar GetcountriesDetails()
        {
            return holiday;
        }

    // public HolidayCalendar GetHolidayData(){
              
             // return holiday;

   //  }
    /*  public void AddHoliday(HolidayCalendar con)
        {
            holiday.HolidayDate = con.HolidayDate;
            holiday.Description = con.date;
            holiday.date = con.date;
            holiday.date = con.date;
        }*/
}

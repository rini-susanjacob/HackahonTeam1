﻿using System;
using System.Collections.Generic;

namespace Hackathon.Models;

public partial class LoggerTable
{
    public short Id { get; set; }

    public string UserName { get; set; } = null!;

    public DateOnly AccessDate { get; set; }

    public string AccessPage { get; set; } = null!;
}
